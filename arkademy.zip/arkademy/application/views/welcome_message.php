<!DOCTYPE html>
<html>
<head>
	<title>Arkademy</title>
</head>
<body>
	<table>
		<tr>
			<th><a href="<?=base_url('tambah_data');?>">Tambah Data</a></th>
			<th><a href="<?=base_url('tampil_data');?>">Tampil Data</a></th>
		</tr>
	</table>
</body>
</html>